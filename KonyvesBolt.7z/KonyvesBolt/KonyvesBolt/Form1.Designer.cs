﻿
namespace KonyvesBolt
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox_TudomanyosKonyv = new System.Windows.Forms.ListBox();
            this.listBox_IrodalmiKonyv = new System.Windows.Forms.ListBox();
            this.button_Uj = new System.Windows.Forms.Button();
            this.button_Modositas = new System.Windows.Forms.Button();
            this.button_Torles = new System.Windows.Forms.Button();
            this.button_Mentes = new System.Windows.Forms.Button();
            this.button_UjIrodalmi = new System.Windows.Forms.Button();
            this.button_IrodalmiModositas = new System.Windows.Forms.Button();
            this.button_IrodalmikonyvTorles = new System.Windows.Forms.Button();
            this.button_IrodalmikonyvMentes = new System.Windows.Forms.Button();
            this.button_OsszesMentes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox_TudomanyosKonyv
            // 
            this.listBox_TudomanyosKonyv.FormattingEnabled = true;
            this.listBox_TudomanyosKonyv.ItemHeight = 15;
            this.listBox_TudomanyosKonyv.Location = new System.Drawing.Point(13, 13);
            this.listBox_TudomanyosKonyv.Name = "listBox_TudomanyosKonyv";
            this.listBox_TudomanyosKonyv.Size = new System.Drawing.Size(306, 154);
            this.listBox_TudomanyosKonyv.TabIndex = 0;
            // 
            // listBox_IrodalmiKonyv
            // 
            this.listBox_IrodalmiKonyv.FormattingEnabled = true;
            this.listBox_IrodalmiKonyv.ItemHeight = 15;
            this.listBox_IrodalmiKonyv.Location = new System.Drawing.Point(351, 13);
            this.listBox_IrodalmiKonyv.Name = "listBox_IrodalmiKonyv";
            this.listBox_IrodalmiKonyv.Size = new System.Drawing.Size(306, 154);
            this.listBox_IrodalmiKonyv.TabIndex = 1;
            // 
            // button_Uj
            // 
            this.button_Uj.Location = new System.Drawing.Point(13, 174);
            this.button_Uj.Name = "button_Uj";
            this.button_Uj.Size = new System.Drawing.Size(306, 23);
            this.button_Uj.TabIndex = 2;
            this.button_Uj.Text = "Új tudományos könyv";
            this.button_Uj.UseVisualStyleBackColor = true;
            this.button_Uj.Click += new System.EventHandler(this.button_Uj_Click);
            // 
            // button_Modositas
            // 
            this.button_Modositas.Location = new System.Drawing.Point(13, 204);
            this.button_Modositas.Name = "button_Modositas";
            this.button_Modositas.Size = new System.Drawing.Size(306, 23);
            this.button_Modositas.TabIndex = 3;
            this.button_Modositas.Text = "Tudományos könyv Módosítása";
            this.button_Modositas.UseVisualStyleBackColor = true;
            this.button_Modositas.Click += new System.EventHandler(this.button_Modositas_Click);
            // 
            // button_Torles
            // 
            this.button_Torles.Location = new System.Drawing.Point(13, 234);
            this.button_Torles.Name = "button_Torles";
            this.button_Torles.Size = new System.Drawing.Size(306, 23);
            this.button_Torles.TabIndex = 4;
            this.button_Torles.Text = "Tudományos könyv Törlése";
            this.button_Torles.UseVisualStyleBackColor = true;
            this.button_Torles.Click += new System.EventHandler(this.button_Torles_Click);
            // 
            // button_Mentes
            // 
            this.button_Mentes.Location = new System.Drawing.Point(13, 264);
            this.button_Mentes.Name = "button_Mentes";
            this.button_Mentes.Size = new System.Drawing.Size(306, 23);
            this.button_Mentes.TabIndex = 5;
            this.button_Mentes.Text = "Tudományos könyv Mentés";
            this.button_Mentes.UseVisualStyleBackColor = true;
            this.button_Mentes.Click += new System.EventHandler(this.button_Mentes_Click);
            // 
            // button_UjIrodalmi
            // 
            this.button_UjIrodalmi.Location = new System.Drawing.Point(351, 174);
            this.button_UjIrodalmi.Name = "button_UjIrodalmi";
            this.button_UjIrodalmi.Size = new System.Drawing.Size(306, 23);
            this.button_UjIrodalmi.TabIndex = 6;
            this.button_UjIrodalmi.Text = "Új irodalmi könyv";
            this.button_UjIrodalmi.UseVisualStyleBackColor = true;
            this.button_UjIrodalmi.Click += new System.EventHandler(this.button_UjIrodalmi_Click);
            // 
            // button_IrodalmiModositas
            // 
            this.button_IrodalmiModositas.Location = new System.Drawing.Point(351, 204);
            this.button_IrodalmiModositas.Name = "button_IrodalmiModositas";
            this.button_IrodalmiModositas.Size = new System.Drawing.Size(306, 23);
            this.button_IrodalmiModositas.TabIndex = 7;
            this.button_IrodalmiModositas.Text = "Irodalmi könyv Módosítása";
            this.button_IrodalmiModositas.UseVisualStyleBackColor = true;
            this.button_IrodalmiModositas.Click += new System.EventHandler(this.button_IrodalmiModositas_Click);
            // 
            // button_IrodalmikonyvTorles
            // 
            this.button_IrodalmikonyvTorles.Location = new System.Drawing.Point(351, 234);
            this.button_IrodalmikonyvTorles.Name = "button_IrodalmikonyvTorles";
            this.button_IrodalmikonyvTorles.Size = new System.Drawing.Size(306, 23);
            this.button_IrodalmikonyvTorles.TabIndex = 8;
            this.button_IrodalmikonyvTorles.Text = "Irodalmi könyv Törlése";
            this.button_IrodalmikonyvTorles.UseVisualStyleBackColor = true;
            this.button_IrodalmikonyvTorles.Click += new System.EventHandler(this.button_IrodalmikonyvTorles_Click);
            // 
            // button_IrodalmikonyvMentes
            // 
            this.button_IrodalmikonyvMentes.Location = new System.Drawing.Point(351, 264);
            this.button_IrodalmikonyvMentes.Name = "button_IrodalmikonyvMentes";
            this.button_IrodalmikonyvMentes.Size = new System.Drawing.Size(306, 23);
            this.button_IrodalmikonyvMentes.TabIndex = 9;
            this.button_IrodalmikonyvMentes.Text = "Irodalmi könyv Mentés";
            this.button_IrodalmikonyvMentes.UseVisualStyleBackColor = true;
            this.button_IrodalmikonyvMentes.Click += new System.EventHandler(this.button_IrodalmikonyvMentes_Click);
            // 
            // button_OsszesMentes
            // 
            this.button_OsszesMentes.Location = new System.Drawing.Point(13, 337);
            this.button_OsszesMentes.Name = "button_OsszesMentes";
            this.button_OsszesMentes.Size = new System.Drawing.Size(306, 23);
            this.button_OsszesMentes.TabIndex = 10;
            this.button_OsszesMentes.Text = "Összes könyv Mentése";
            this.button_OsszesMentes.UseVisualStyleBackColor = true;
            this.button_OsszesMentes.Click += new System.EventHandler(this.button_OsszesMentes_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 437);
            this.Controls.Add(this.button_OsszesMentes);
            this.Controls.Add(this.button_IrodalmikonyvMentes);
            this.Controls.Add(this.button_IrodalmikonyvTorles);
            this.Controls.Add(this.button_IrodalmiModositas);
            this.Controls.Add(this.button_UjIrodalmi);
            this.Controls.Add(this.button_Mentes);
            this.Controls.Add(this.button_Torles);
            this.Controls.Add(this.button_Modositas);
            this.Controls.Add(this.button_Uj);
            this.Controls.Add(this.listBox_IrodalmiKonyv);
            this.Controls.Add(this.listBox_TudomanyosKonyv);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_Uj;
        private System.Windows.Forms.Button button_Modositas;
        private System.Windows.Forms.Button button_Torles;
        private System.Windows.Forms.Button button_Mentes;
        private System.Windows.Forms.Button button_UjIrodalmi;
        private System.Windows.Forms.Button button_IrodalmiModositas;
        private System.Windows.Forms.Button button_IrodalmikonyvTorles;
        private System.Windows.Forms.Button button_IrodalmikonyvMentes;
        private System.Windows.Forms.Button button_OsszesMentes;
        public System.Windows.Forms.ListBox listBox_TudomanyosKonyv;
        public System.Windows.Forms.ListBox listBox_IrodalmiKonyv;
    }
}

