﻿
namespace KonyvesBolt
{
    partial class TudomanyosKonyvAblak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_TKMegse = new System.Windows.Forms.Button();
            this.button_TKOk = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_TKTudomany = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.NUD_TKAr = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.NUD_TK_Oldalszam = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_TKSzerzo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_TKCim = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown_Tudomany = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_TKAr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_TK_Oldalszam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Tudomany)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown_Tudomany);
            this.groupBox1.Controls.Add(this.button_TKMegse);
            this.groupBox1.Controls.Add(this.button_TKOk);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.comboBox_TKTudomany);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.NUD_TKAr);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.NUD_TK_Oldalszam);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox_TKSzerzo);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox_TKCim);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(178, 425);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tudományos Könyv";
            // 
            // button_TKMegse
            // 
            this.button_TKMegse.Location = new System.Drawing.Point(7, 391);
            this.button_TKMegse.Name = "button_TKMegse";
            this.button_TKMegse.Size = new System.Drawing.Size(158, 23);
            this.button_TKMegse.TabIndex = 15;
            this.button_TKMegse.Text = "Mégse";
            this.button_TKMegse.UseVisualStyleBackColor = true;
            this.button_TKMegse.Click += new System.EventHandler(this.button_TKMegse_Click);
            // 
            // button_TKOk
            // 
            this.button_TKOk.Location = new System.Drawing.Point(7, 361);
            this.button_TKOk.Name = "button_TKOk";
            this.button_TKOk.Size = new System.Drawing.Size(158, 23);
            this.button_TKOk.TabIndex = 14;
            this.button_TKOk.Text = "OK";
            this.button_TKOk.UseVisualStyleBackColor = true;
            this.button_TKOk.Click += new System.EventHandler(this.button_TKOk_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(8, 335);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(49, 19);
            this.checkBox1.TabIndex = 13;
            this.checkBox1.Text = "Igen";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 317);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Elismert könyv";
            // 
            // comboBox_TKTudomany
            // 
            this.comboBox_TKTudomany.FormattingEnabled = true;
            this.comboBox_TKTudomany.Location = new System.Drawing.Point(7, 287);
            this.comboBox_TKTudomany.Name = "comboBox_TKTudomany";
            this.comboBox_TKTudomany.Size = new System.Drawing.Size(158, 23);
            this.comboBox_TKTudomany.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tudomány terület";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Kiadás éve";
            // 
            // NUD_TKAr
            // 
            this.NUD_TKAr.Location = new System.Drawing.Point(7, 189);
            this.NUD_TKAr.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.NUD_TKAr.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NUD_TKAr.Name = "NUD_TKAr";
            this.NUD_TKAr.Size = new System.Drawing.Size(158, 23);
            this.NUD_TKAr.TabIndex = 7;
            this.NUD_TKAr.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Ár";
            // 
            // NUD_TK_Oldalszam
            // 
            this.NUD_TK_Oldalszam.Location = new System.Drawing.Point(7, 140);
            this.NUD_TK_Oldalszam.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NUD_TK_Oldalszam.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NUD_TK_Oldalszam.Name = "NUD_TK_Oldalszam";
            this.NUD_TK_Oldalszam.Size = new System.Drawing.Size(158, 23);
            this.NUD_TK_Oldalszam.TabIndex = 5;
            this.NUD_TK_Oldalszam.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Oldal szám";
            // 
            // textBox_TKSzerzo
            // 
            this.textBox_TKSzerzo.Location = new System.Drawing.Point(7, 91);
            this.textBox_TKSzerzo.Name = "textBox_TKSzerzo";
            this.textBox_TKSzerzo.Size = new System.Drawing.Size(158, 23);
            this.textBox_TKSzerzo.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Szerző";
            // 
            // textBox_TKCim
            // 
            this.textBox_TKCim.Location = new System.Drawing.Point(7, 42);
            this.textBox_TKCim.Name = "textBox_TKCim";
            this.textBox_TKCim.Size = new System.Drawing.Size(158, 23);
            this.textBox_TKCim.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cím";
            // 
            // numericUpDown_Tudomany
            // 
            this.numericUpDown_Tudomany.Location = new System.Drawing.Point(7, 238);
            this.numericUpDown_Tudomany.Maximum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.numericUpDown_Tudomany.Minimum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.numericUpDown_Tudomany.Name = "numericUpDown_Tudomany";
            this.numericUpDown_Tudomany.Size = new System.Drawing.Size(158, 23);
            this.numericUpDown_Tudomany.TabIndex = 16;
            this.numericUpDown_Tudomany.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_Tudomany.Value = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            // 
            // TudomanyosKonyvAblak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(199, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "TudomanyosKonyvAblak";
            this.Text = "TudomanyosKonyvAblak";
            this.Load += new System.EventHandler(this.TudomanyosKonyvAblak_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_TKAr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_TK_Oldalszam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Tudomany)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown NUD_TKAr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown NUD_TK_Oldalszam;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_TKSzerzo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_TKCim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_TKTudomany;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_TKMegse;
        private System.Windows.Forms.Button button_TKOk;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDown_Tudomany;
    }
}